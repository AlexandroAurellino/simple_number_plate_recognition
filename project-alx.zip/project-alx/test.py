import unittest
from io import StringIO

from BinaryTreeTest import BinaryTree

class TestBinaryTree(unittest.TestCase):
    def setUp(self):
        """Initialize the tree and insert test nodes before each test."""
        self.tree = BinaryTree()
        for node in [50, 30, 70, 20, 40, 60, 80]:
            self.tree.insert(node)
        
    def test_insert_unique(self):
        result = self.tree.insert(1)
        expected = True
        self.assertEqual(result, expected, "Insert Data Unique failed")

    def test_insert_duplicate(self):
        result = self.tree.insert(40)
        expected = False
        self.assertEqual(result, expected, "Insert Data Duplicate failed")

    def test_inorder_traversal(self):
        """Test the inorder traversal."""
        result = self.tree.inorder_traversal()
        expected = [20, 30, 40, 50, 60, 70, 80]
        self.assertEqual(result, expected, "Inorder traversal failed")

    def test_find(self):
        """Test the find operation."""
        self.assertTrue(self.tree.find(60), "Find operation failed for existing node")
        self.assertFalse(self.tree.find(90), "Find operation failed for non-existing node")

    def test_delete(self):
        """Test the delete operation."""
        self.tree.delete(50)  # Delete root node
        result = self.tree.inorder_traversal()
        expected = [20, 30, 40, 60, 70, 80]
        self.assertEqual(result, expected, "Delete operation failed for root node")

    def test_height(self):
        """Test the height calculation."""
        self.assertEqual(self.tree.height(), 3, "Height calculation failed")

    def test_count_nodes(self):
        """Test the node count."""
        self.assertEqual(self.tree.count_nodes(), 7, "Node count failed")
        self.tree.delete(50)
        self.assertEqual(self.tree.count_nodes(), 6, "Node count failed after deletion")

    @staticmethod
    def run_tests():
        """Run all tests and calculate marks based on criteria."""
        suite = unittest.TestLoader().loadTestsFromTestCase(TestBinaryTree)
        results = unittest.TextTestRunner(stream=StringIO()).run(suite)

        # Criteria-based evaluation
        total_tests = results.testsRun
        failed_tests = len(results.failures) + len(results.errors)
        passed_tests = total_tests - failed_tests

        # Evaluation Criteria
        marks_per_test = 100 / total_tests
        marks = passed_tests * marks_per_test

        print(f"Total Tests Run: {total_tests}")
        print(f"Passed Tests: {passed_tests}")
        print(f"Failed Tests: {failed_tests}")
        print(f"Marks Earned: {marks:.2f} / 100")

        with open("test_results.txt", "w") as file:
            file.write("\n")
            file.write(f"Total Tests Run: {total_tests}\n")
            file.write(f"Passed Tests: {passed_tests}\n")
            file.write(f"Failed Tests: {failed_tests}\n")
            file.write(f"Marks Earned: {marks:.2f} / 100\n")

        print(f"Test results saved to 'test_results.txt'.")

if __name__ == "__main__":
    TestBinaryTree.run_tests()
