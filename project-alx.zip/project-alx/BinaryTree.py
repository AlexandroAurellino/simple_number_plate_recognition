class Node:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

class BinaryTree:
    def __init__(self):
        self.root = None

    def insert(self, data):
        def _insert_rec(node, data):
            if node is None:
                return Node(data)
            elif data < node.data:
                node.left = _insert_rec(node.left, data)
            elif data > node.data:
                node.right = _insert_rec(node.right, data)
            return node

        if not self.find(data):
            self.root = _insert_rec(self.root, data)
            return True
        return False

    def inorder_traversal(self):
        def _inorder(node):
            if node is None:
                return []
            return _inorder(node.left) + [node.data] + _inorder(node.right)

        return _inorder(self.root)

    def find(self, data):
        def _find_rec(node, data):
            if node is None:
                return False
            if node.data == data:
                return True
            elif data < node.data:
                return _find_rec(node.left, data)
            else:
                return _find_rec(node.right, data)

        return _find_rec(self.root, data)

    def delete(self, data):
        def _delete_rec(node, data):
            if node is None:
                return None
            if data < node.data:
                node.left = _delete_rec(node.left, data)
            elif data > node.data:
                node.right = _delete_rec(node.right, data)
            else:
                # Node with only one child or no child
                if node.left is None:
                    return node.right
                elif node.right is None:
                    return node.left

                # Node with two children: Get the inorder successor
                temp = self._min_value_node(node.right)
                node.data = temp.data
                node.right = _delete_rec(node.right, temp.data)

            return node

        self.root = _delete_rec(self.root, data)

    def _min_value_node(self, node):
        current = node
        while current and current.left is not None:
            current = current.left
        return current

    def height(self):
        def _height(node):
            if node is None:
                return 0
            return 1 + max(_height(node.left), _height(node.right))

        return _height(self.root)

    def count_nodes(self):
        def _count_rec(node):
            if node is None:
                return 0
            return 1 + _count_rec(node.left) + _count_rec(node.right)

        return _count_rec(self.root)

# Studi kasus
if __name__ == "__main__":
    tree = BinaryTree()

    # Insert nodes
    nodes = [50, 30, 70, 20, 40, 60, 80]
    for node in nodes:
        tree.insert(node)

    # Traversals
    print("Inorder Traversal:", tree.inorder_traversal())

    # Search
    print("Cari 60:", "Ditemukan" if tree.find(60) else "Tidak ditemukan")
    print("Cari 90:", "Ditemukan" if tree.find(90) else "Tidak ditemukan")

    # Delete
    print("Menghapus 50 (root node)...")
    tree.delete(50)
    print("Inorder Traversal setelah menghapus:", tree.inorder_traversal())

    # Height and Node Count
    print("Height binary tree:", tree.height())
    print("Total nodes:", tree.count_nodes())
